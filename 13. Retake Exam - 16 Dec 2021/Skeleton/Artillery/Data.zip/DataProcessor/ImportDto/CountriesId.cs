﻿namespace Artillery.DataProcessor.ImportDto
{
    public class CountriesId
    {
        public int Id { get; set; }
    }
}
